	</section>
</div>	
</body>

<script type="text/javascript" src="<?= base_url('assets/bootstrap/js/bootstrap.js')?>"></script>
<script type="text/javascript" src="<?= base_url('assets/fontawesome/js/all.js')?>"></script>
</html>